/*******************************
Sample benchmark program
*******************************/

#include <stdio.h>
//include any library or files

int main(int argc, char **argv)
{
 

// IMPORTANT print success message 
  printf("\nstatus sucess\n");
  return 0;
}
