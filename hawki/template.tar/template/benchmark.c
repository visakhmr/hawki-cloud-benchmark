/*******************************
Sample benchmark program
This should be the main file
*******************************/

#include <stdio.h>
//include any library or files

int main(int argc, char **argv)
{
//TODO Add benchmark source code or call a library function 

// IMPORTANT print success message 
  printf("\nstatus sucess\n");
  return 0;
}
