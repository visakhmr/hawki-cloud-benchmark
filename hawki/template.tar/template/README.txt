Edit Makefile to set the compiler
Edit Perl script and set the benchmark name{executable}
Run perlscript
./submit.pl <numprocs>
